import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/category.dart';
import '../models/article.dart';

class ApiService {
  static const String baseUrl = 'https://apiforlearning.zendvn.com/api/v2';

  static Future<List<Category>> getCategories() async {
    final response = await http.get(Uri.parse('$baseUrl/categories_news'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List list = data is List ? data : (data['data'] ?? []);
      return list.map((e) => Category.fromJson(e)).toList();
    }
    throw Exception('Failed to load categories');
  }

  static Future<List<Article>> getArticlesByCategory(int categoryId,
      {int limit = 20, int page = 1}) async {
    final response = await http.get(
      Uri.parse(
          '$baseUrl/categories_news/$categoryId/articles?limit=$limit&page=$page'),
    );
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List list = data is List ? data : (data['data'] ?? []);
      return list.map((e) => Article.fromJson(e)).toList();
    }
    throw Exception('Failed to load articles');
  }

  static Future<Article> getArticleDetail(int articleId) async {
    final response =
        await http.get(Uri.parse('$baseUrl/articles/$articleId'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final articleData = data is Map<String, dynamic> &&
              data.containsKey('data')
          ? data['data']
          : data;
      return Article.fromJson(articleData);
    }
    throw Exception('Failed to load article detail');
  }

  static Future<List<Article>> getRelatedArticles(int articleId,
      {int limit = 10}) async {
    final response = await http.get(
      Uri.parse('$baseUrl/articles/$articleId/related?limit=$limit'),
    );
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List list = data is List ? data : (data['data'] ?? []);
      return list.map((e) => Article.fromJson(e)).toList();
    }
    throw Exception('Failed to load related articles');
  }

  static Future<List<Article>> getPopularArticles({int limit = 5}) async {
    final response = await http.get(
      Uri.parse('$baseUrl/articles/popular?limit=$limit'),
    );
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List list = data is List ? data : (data['data'] ?? []);
      return list.map((e) => Article.fromJson(e)).toList();
    }
    throw Exception('Failed to load popular articles');
  }
}
