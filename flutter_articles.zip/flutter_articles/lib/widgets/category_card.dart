import 'package:flutter/material.dart';
import '../models/category.dart';

class CategoryCard extends StatelessWidget {
  final Category category;
  final VoidCallback onTap;

  const CategoryCard({super.key, required this.category, required this.onTap});

  Color _getColor() {
    final colors = [
      const Color(0xFF6C63FF), const Color(0xFFFF6584),
      const Color(0xFF43E97B), const Color(0xFFFA709A),
      const Color(0xFF667EEA), const Color(0xFFF093FB),
      const Color(0xFF4FACFE), const Color(0xFFF5576C),
      const Color(0xFF0BA360), const Color(0xFFFFA726),
    ];
    return colors[category.id % colors.length];
  }

  IconData _getIcon() {
    final icons = [
      Icons.article_outlined, Icons.sports_soccer,
      Icons.movie_outlined, Icons.science_outlined,
      Icons.computer, Icons.health_and_safety,
      Icons.travel_explore, Icons.restaurant,
      Icons.music_note, Icons.school,
    ];
    return icons[category.id % icons.length];
  }

  @override
  Widget build(BuildContext context) {
    final color = _getColor();
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, color.withOpacity(0.7)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4))],
        ),
        child: Stack(children: [
          Positioned(right: -10, bottom: -10,
            child: Icon(_getIcon(), size: 80, color: Colors.white.withOpacity(0.15))),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(_getIcon(), color: Colors.white, size: 28),
                ),
                const SizedBox(height: 12),
                Text(category.name,
                  style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
                if (category.totalArticles != null) ...[
                  const SizedBox(height: 4),
                  Text('${category.totalArticles} articles',
                    style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12)),
                ],
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
