import 'package:flutter/material.dart';
import '../models/category.dart';
import '../models/article.dart';
import '../services/api_service.dart';
import '../widgets/category_card.dart';
import '../widgets/article_card.dart';
import 'category_articles_screen.dart';
import 'article_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Category> _categories = [];
  List<Article> _popularArticles = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      final results = await Future.wait([
        ApiService.getCategories(),
        ApiService.getPopularArticles(limit: 6),
      ]);
      setState(() {
        _categories = results[0] as List<Category>;
        _popularArticles = results[1] as List<Article>;
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  void _goCategory(Category c) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryArticlesScreen(category: c)));
  }
  void _goDetail(Article a) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ArticleDetailScreen(articleId: a.id)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: SafeArea(
        child: _isLoading ? const Center(child: CircularProgressIndicator())
          : _error != null ? _buildError()
          : RefreshIndicator(onRefresh: _loadData,
              child: CustomScrollView(slivers: [
                SliverToBoxAdapter(child: _buildHeader()),
                SliverToBoxAdapter(child: _sectionTitle('Categories', Icons.category)),
                SliverToBoxAdapter(child: _buildGrid()),
                if (_popularArticles.isNotEmpty) ...[
                  SliverToBoxAdapter(child: _sectionTitle('Popular', Icons.local_fire_department)),
                  SliverToBoxAdapter(child: _buildPopular()),
                ],
                const SliverToBoxAdapter(child: SizedBox(height: 24)),
              ])),
      ),
    );
  }

  Widget _buildHeader() => Container(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
    child: Row(children: [
      Container(padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: const Color(0xFF6C63FF).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
        child: const Icon(Icons.auto_stories, color: Color(0xFF6C63FF), size: 28)),
      const SizedBox(width: 12),
      const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Articles Hub', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF1A1A2E))),
        Text('Explore categories & read articles', style: TextStyle(fontSize: 13, color: Colors.grey)),
      ]),
    ]));

  Widget _sectionTitle(String t, IconData i) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
    child: Row(children: [
      Icon(i, color: const Color(0xFF6C63FF), size: 22), const SizedBox(width: 8),
      Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1A1A2E))),
    ]));

  Widget _buildGrid() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.4),
      itemCount: _categories.length,
      itemBuilder: (_, i) => CategoryCard(category: _categories[i], onTap: () => _goCategory(_categories[i]))));

  Widget _buildPopular() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Column(children: _popularArticles.map((a) => ArticleCard(article: a, onTap: () => _goDetail(a))).toList()));

  Widget _buildError() => Center(child: Padding(
    padding: const EdgeInsets.all(24),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.cloud_off, size: 64, color: Colors.grey), const SizedBox(height: 16),
      Text('Cannot load data', style: TextStyle(fontSize: 18, color: Colors.grey[700])),
      Text(_error ?? '', style: TextStyle(fontSize: 13, color: Colors.grey[500]), textAlign: TextAlign.center),
      const SizedBox(height: 20),
      ElevatedButton.icon(onPressed: _loadData, icon: const Icon(Icons.refresh), label: const Text('Retry'),
        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6C63FF), foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))),
    ])));
}
