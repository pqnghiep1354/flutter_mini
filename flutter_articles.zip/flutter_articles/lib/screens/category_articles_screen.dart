import 'package:flutter/material.dart';
import '../models/category.dart';
import '../models/article.dart';
import '../services/api_service.dart';
import '../widgets/article_card.dart';
import 'article_detail_screen.dart';

class CategoryArticlesScreen extends StatefulWidget {
  final Category category;
  const CategoryArticlesScreen({super.key, required this.category});
  @override
  State<CategoryArticlesScreen> createState() => _CategoryArticlesScreenState();
}

class _CategoryArticlesScreenState extends State<CategoryArticlesScreen> {
  List<Article> _articles = [];
  bool _isLoading = true;
  bool _isGrid = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      final articles = await ApiService.getArticlesByCategory(widget.category.id, limit: 20);
      setState(() { _articles = articles; _isLoading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  void _goDetail(Article a) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ArticleDetailScreen(articleId: a.id)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: AppBar(
        title: Text(widget.category.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: Colors.white, foregroundColor: const Color(0xFF1A1A2E), elevation: 0,
        actions: [IconButton(icon: Icon(_isGrid ? Icons.view_list : Icons.grid_view),
          onPressed: () => setState(() => _isGrid = !_isGrid))],
      ),
      body: _isLoading ? const Center(child: CircularProgressIndicator())
        : _error != null ? _err()
        : _articles.isEmpty ? _empty()
        : RefreshIndicator(onRefresh: _load, child: _isGrid ? _grid() : _list()),
    );
  }

  Widget _grid() => Padding(padding: const EdgeInsets.all(16),
    child: GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.75),
      itemCount: _articles.length,
      itemBuilder: (_, i) => ArticleGridCard(article: _articles[i], onTap: () => _goDetail(_articles[i]))));

  Widget _list() => ListView.builder(padding: const EdgeInsets.all(16), itemCount: _articles.length,
    itemBuilder: (_, i) => ArticleCard(article: _articles[i], onTap: () => _goDetail(_articles[i])));

  Widget _empty() => const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Icon(Icons.article_outlined, size: 64, color: Colors.grey), SizedBox(height: 16),
    Text('No articles found', style: TextStyle(color: Colors.grey, fontSize: 16))]));

  Widget _err() => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Icon(Icons.error_outline, size: 64, color: Colors.grey), const SizedBox(height: 16),
    Text(_error ?? '', style: const TextStyle(color: Colors.grey)), const SizedBox(height: 16),
    ElevatedButton(onPressed: _load,
      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6C63FF), foregroundColor: Colors.white),
      child: const Text('Retry'))]));
}
