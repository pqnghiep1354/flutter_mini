import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_html/flutter_html.dart';
import '../models/article.dart';
import '../services/api_service.dart';
import '../widgets/article_card.dart';

class ArticleDetailScreen extends StatefulWidget {
  final int articleId;
  const ArticleDetailScreen({super.key, required this.articleId});
  @override
  State<ArticleDetailScreen> createState() => _ArticleDetailScreenState();
}

class _ArticleDetailScreenState extends State<ArticleDetailScreen> {
  Article? _article;
  List<Article> _related = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      final results = await Future.wait([
        ApiService.getArticleDetail(widget.articleId),
        ApiService.getRelatedArticles(widget.articleId, limit: 5),
      ]);
      setState(() {
        _article = results[0] as Article;
        _related = results[1] as List<Article>;
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  void _goDetail(Article a) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ArticleDetailScreen(articleId: a.id)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: _isLoading ? const Center(child: CircularProgressIndicator())
        : _error != null ? _buildErr() : _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_article == null) return const SizedBox.shrink();
    final a = _article!;
    return CustomScrollView(slivers: [
      SliverAppBar(
        expandedHeight: 250, pinned: true,
        backgroundColor: const Color(0xFF1A1A2E),
        foregroundColor: Colors.white,
        flexibleSpace: FlexibleSpaceBar(
          background: a.thumb != null && a.thumb!.isNotEmpty
            ? CachedNetworkImage(imageUrl: a.thumb!, fit: BoxFit.cover,
                placeholder: (c, u) => Container(color: Colors.grey[300]),
                errorWidget: (c, u, e) => Container(color: Colors.grey[300],
                  child: const Icon(Icons.image, size: 48, color: Colors.grey)))
            : Container(color: const Color(0xFF6C63FF),
                child: const Icon(Icons.article, size: 64, color: Colors.white54)),
        ),
      ),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (a.categoryName != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFF6C63FF).withOpacity(0.1),
                borderRadius: BorderRadius.circular(8)),
              child: Text(a.categoryName!,
                style: const TextStyle(color: Color(0xFF6C63FF),
                  fontWeight: FontWeight.w600, fontSize: 12))),
          const SizedBox(height: 14),
          Text(a.title, style: const TextStyle(fontSize: 22,
            fontWeight: FontWeight.bold, color: Color(0xFF1A1A2E), height: 1.3)),
          const SizedBox(height: 12),
          Row(children: [
            if (a.views != null) ...[
              Icon(Icons.visibility, size: 16, color: Colors.grey[500]),
              const SizedBox(width: 4),
              Text('${a.views} views', style: TextStyle(color: Colors.grey[500], fontSize: 13)),
              const SizedBox(width: 16)],
            if (a.createdAt != null) ...[
              Icon(Icons.access_time, size: 16, color: Colors.grey[500]),
              const SizedBox(width: 4),
              Text(a.createdAt!, style: TextStyle(color: Colors.grey[500], fontSize: 13))],
          ]),
          const SizedBox(height: 16),
          Divider(color: Colors.grey[200]),
          const SizedBox(height: 8),
          if (a.description != null && a.description!.isNotEmpty) ...[
            Text(a.description!, style: TextStyle(fontSize: 15, color: Colors.grey[700], fontStyle: FontStyle.italic, height: 1.5)),
            const SizedBox(height: 16)],
          if (a.content != null && a.content!.isNotEmpty)
            Html(data: a.content!),
          if (_related.isNotEmpty) ...[
            const SizedBox(height: 24),
            Divider(color: Colors.grey[200]),
            const SizedBox(height: 16),
            const Row(children: [
              Icon(Icons.recommend, color: Color(0xFF6C63FF), size: 22),
              SizedBox(width: 8),
              Text('Related Articles', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1A1A2E)))]),
            const SizedBox(height: 12),
            ..._related.map((ar) => ArticleCard(article: ar, onTap: () => _goDetail(ar))),
          ],
        ]),
      )),
    ]);
  }

  Widget _buildErr() => Center(child: Column(
    mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.error_outline, size: 64, color: Colors.grey),
      const SizedBox(height: 16),
      Text(_error ?? '', style: const TextStyle(color: Colors.grey)),
      const SizedBox(height: 16),
      ElevatedButton(onPressed: _load,
        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6C63FF), foregroundColor: Colors.white),
        child: const Text('Retry'))]));
}
